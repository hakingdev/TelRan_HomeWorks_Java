import java.util.Locale;

public class Main2 {
    public static void main(String[] args) {
        String string = new String("I study Basic Java!");
        System.out.println(string.charAt(string.length() - 1));
        if (string.contains("Java")) {
            System.out.println("\"Java\" есть в строке");
        }
        System.out.println(string.replace("a", "o"));
        System.out.println(string.toUpperCase(Locale.of(string)));
        System.out.println(string.toLowerCase(Locale.of(string)));
        System.out.println(string.substring(0, string.lastIndexOf(" ")));
//        String[] words = string.split(" ");

    }
}
