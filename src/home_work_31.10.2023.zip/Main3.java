public class Main3 {
    public static void main(String[] args) {
        String string = "AAAABBBCCCDDEG";
        System.out.println(method(string));
    }

    private static StringBuilder method(String text) {
        StringBuilder result = new StringBuilder();
        char prevLetter = text.charAt(0);
        int count = 0;
        for(int i = 0; i < text.length();i++) {
            char currentLetter = text.charAt(i);
            if (prevLetter == currentLetter) {
                count++;
            } else {
                result.append(prevLetter);
                result.append(count == 1 ? "" : count);
                count = 1;
                prevLetter = currentLetter;
            }
        }
        result.append(prevLetter);
        result.append(count == 1 ? "" : count);
        return result;
    }
}




