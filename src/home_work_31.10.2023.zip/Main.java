import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите первое слово: ");
        String word1 = sc.nextLine();
        System.out.println("Введите второе слово: ");
        String word2 = sc.nextLine();
        String w1 = word1.length() % 2 != 0 ? "Ввели не четное количество символов в слове" : word1.substring(word1.length() / 2);
        String w2 = word2.length() % 2 != 0 ? "Ввели не четное количество символов в слове" : word2.substring(word2.length() / 2);
        System.out.println(w1 + w2);
    }



}
