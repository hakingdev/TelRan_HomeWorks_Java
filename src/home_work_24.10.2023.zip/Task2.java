public class Task2 {
    public static void main(String[] args) {
        System.out.println(fac(4));
    }

    //fac(4)
    //4 * fac(3)
    //3 * fac(2)
    //2 * fac(1)
    //fac(1) -> return 1 идем по стеку вверх и перемножаем все
    private static int fac(int n) {
        if (n <= 1) {
            return 1;
        } else {
            return fac(n - 1) * n;
        }
    }
}
