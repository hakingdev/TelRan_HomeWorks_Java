import java.util.Arrays;
import java.util.Random;

public class Task3 {
    public static void main(String[] args) {
        int[] nums = new int[8];
        System.out.println(Arrays.toString(nums));
        Random rnd = new Random();
        for (int i = 0; i < nums.length; i++) {
            nums[i] = rnd.nextInt(1, 51);
            for (int j = i; j <= i; j++) {
                nums[i] = nums[i] % 2 == 0 ? nums[i] : (nums[i] = 0);
            }
        }
        System.out.println(Arrays.toString(nums));
        Arrays.sort(nums);
        System.out.println(Arrays.toString(nums));
    }
}

