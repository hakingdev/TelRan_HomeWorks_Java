public class Task4 {
    public static void main(String[] args) {
        String[] string = {"Hello", "What", "Name", "Numbers", "Stringsss"};
        int maxOfLength = 0;
        String longWord = "";
        for (int i = 0; i < string.length; i++) {
            if (string[i].length() > maxOfLength) {
                maxOfLength = string[i].length();
                longWord = string[i];
            }
        }
        System.out.println("The longest word is -> " + longWord);
    }
}
