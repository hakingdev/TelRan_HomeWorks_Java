public class Task1 {
    public static void main(String[] args) {
        System.out.println(multiplication2(2, 2));
        System.out.println(multiplication3(2, 2, 2));
        System.out.println(multiplication4(2, 2, 2, 2));
        System.out.println(multiply(2, 3, 4));
    }

    private static int multiplication2(int number1, int number2) {
        return number1 * number2;
    }

    private static int multiplication3(int number1, int number2, int number3) {
        int i = multiplication2(number1, number2);
        return i * number3;
    }

    private static int multiplication4(int number1, int number2, int number3, int number4) {
        int i = multiplication3(number1, number2, number3);
        return i * number4;
    }

    //one more variation
    private static int multiply(int... numbers) {
        int index = 1;
        for (int number:
             numbers) {
            index *= number;
        }
        return index;
    }
}
