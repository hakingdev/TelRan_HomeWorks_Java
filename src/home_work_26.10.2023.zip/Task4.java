import java.util.Arrays;

public class Task4 {
    public static void main(String[] args) {
        char[][] alphabet = new char[6][6];
        char letter = 1040;
        for (int i = 0; i < alphabet.length; i++) {
            for (int j = 0; j < alphabet[i].length; j++) {
                alphabet[i][j] = letter;
                if (letter == 'Ж') {
                    alphabet[i][j] = 1025;
                    j++;
                    alphabet[i][j] = 'Ж';
                }
                letter++;
                if(letter > 'Я') break;
            }
        }
        System.out.println(Arrays.deepToString(alphabet));
    }
}
