import java.time.LocalDate;
import java.util.Locale;

public class Task1 {
    public static void main(String[] args) {
        LocalDate[] dates = new LocalDate[8];

        dates[0] = LocalDate.of(2023, 10, 1);
        dates[1] = LocalDate.of(2023, 10, 2);
        dates[2] = LocalDate.of(2023, 10, 3);
        dates[3] = LocalDate.of(2023, 10, 4);
        dates[4] = LocalDate.of(2023, 10, 5);
        dates[5] = LocalDate.of(2023, 10, 6);
        dates[6] = LocalDate.of(2023, 10, 7);
        dates[7] = LocalDate.of(2023, 10, 8);

        for (LocalDate date : dates) {
            System.out.println(date);
        }
    }
}
