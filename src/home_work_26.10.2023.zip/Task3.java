import java.time.LocalDate;
import java.util.Arrays;
import java.util.Date;

public class Task3 {
    public static void main(String[] args) {
        LocalDate[] dates = new LocalDate[8];

        dates[0] = LocalDate.of(2025, 10, 5);
        dates[1] = LocalDate.of(2021, 10, 2);
        dates[2] = LocalDate.of(2027, 10, 8);
        dates[3] = LocalDate.of(2020, 10, 7);
        dates[4] = LocalDate.of(2019, 10, 10);
        dates[5] = LocalDate.of(2024, 10, 11);
        dates[6] = LocalDate.of(2027, 10, 20);
        dates[7] = LocalDate.of(2028, 10, 3);

        insertionSort(dates);

        for (LocalDate date : dates) {
            System.out.println(date);
        }
    }

    private static void insertionSort(LocalDate[] dates) {
        for (int i = 1; i < dates.length ; i++) {
            LocalDate swap = dates[i];
            int j = i - 1;
            while (j >= 0 && dates[j].getDayOfMonth() > swap.getDayOfMonth()) {
                dates[j + 1] = dates[j];
                j--;
            }
            dates[j + 1] = swap;
        }
    }
}
