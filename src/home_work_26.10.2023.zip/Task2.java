import java.time.LocalDate;
import java.util.Arrays;
import java.util.Locale;

public class Task2 {
    public static void main(String[] args) {
        LocalDate[] dates = new LocalDate[8];

        dates[0] = LocalDate.of(2025, 10, 1);
        dates[1] = LocalDate.of(2021, 10, 2);
        dates[2] = LocalDate.of(2027, 10, 3);
        dates[3] = LocalDate.of(2020, 10, 4);
        dates[4] = LocalDate.of(2019, 10, 5);
        dates[5] = LocalDate.of(2024, 10, 6);
        dates[6] = LocalDate.of(2027, 10, 7);
        dates[7] = LocalDate.of(2028, 10, 8);

        bubbleSorted(dates);

        for (LocalDate date : dates) {
            System.out.println(date);
        }
    }

    private static void bubbleSorted(LocalDate[] dates) {
        for (int i = 0; i < dates.length - 1; i++) {
            for (int j = 0; j < dates.length - i - 1; j++) {
                if (dates[j].getYear() > dates[j + 1].getYear()) {
                    LocalDate newDate = dates[j];
                    dates[j] = dates[j + 1];
                    dates[j + 1] = newDate;
                }
            }
        }
    }
}
